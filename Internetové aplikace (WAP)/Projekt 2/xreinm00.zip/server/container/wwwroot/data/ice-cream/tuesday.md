# Tuesday's ice cream flavours
    - Chocolate
    - Gum
    - Cookies
    - Pineapple
    - Orange
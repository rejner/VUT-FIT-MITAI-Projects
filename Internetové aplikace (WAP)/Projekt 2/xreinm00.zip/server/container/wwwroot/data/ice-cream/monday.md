# Monday's ice cream flavours
    - Vanilla
    - Apple
    - Cherry
    - Banana
    - Nougat
# Data description

## ice-cream
    - contains ice-cream flavours for each day